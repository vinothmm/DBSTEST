package com.test.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.test.dto.User;
import com.test.services.UserService;
 
@RestController
public class UserController {
	
	@Autowired
    private UserService userServ;
	
	 @GetMapping(value="/getUser/{User-id}")
	    @ResponseBody
	    public ResponseEntity<User> getUserById(@PathVariable("User-id") int UserId) { 
		 System.out.println(UserId);
	        Optional<User> User = userServ.getUserById(UserId);
	        System.out.println(User.isPresent());
	        if(!User.isPresent())
	            return new ResponseEntity<User>(HttpStatus.NOT_FOUND);
	 System.out.println(User.isPresent());
	        return new ResponseEntity<User>(User.get(), HttpStatus.OK);
	    }
	 
	    
	    @PutMapping(value="/{User-id}/{User-name}")
	    public ResponseEntity<User> updateTicketById(@PathVariable("User-id") int UserId, @PathVariable("User-name") String UserName) {
	        Optional<User> User = userServ.getUserById(UserId);
	        if(!User.isPresent())
	            return new ResponseEntity<User>(HttpStatus.NOT_FOUND);
	 
	        return new ResponseEntity<User>(userServ.updateUserById(User.get(), UserName), HttpStatus.OK);
	    }
	 
	  
	    @DeleteMapping(value="/delete/{User-id}")
	    public ResponseEntity<User> deleteUserById(@PathVariable("User-id") int UserId) {
	        Optional<User> User = userServ.getUserById(UserId);
	        if(!User.isPresent())
	            return new ResponseEntity<User>(HttpStatus.NOT_FOUND);
	 
	        userServ.deleteUserById(UserId);
	        return new ResponseEntity<User>(HttpStatus.ACCEPTED);
	    }

}

package com.test.services;
 
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.test.dao.UserRepo;
import com.test.dto.User;

@Service
public class UserService {
	
    
	@Autowired
    private UserRepo prepo;
    
    @Cacheable(value="userCache", key="#p0")
    public Optional<User> getUserById(int userId) {
        return prepo.findById(userId);
    }
    
    @CachePut(value="userCache")
    public User updateUserById(User user, String userName) {
    	user.setName(userName);
        prepo.save(user);
 
        return user;
    }
    
    @CacheEvict(value="userCache", key="#p0")
    public void deleteUserById(int userId) {
        prepo.deleteById(userId);
    }

}

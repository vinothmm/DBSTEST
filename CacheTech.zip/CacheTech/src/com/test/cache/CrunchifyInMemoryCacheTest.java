package com.test.cache;

 
 
/**
 * @author Crunchify.com
 */
 
public class CrunchifyInMemoryCacheTest {
 
    public static void main(String[] args) throws InterruptedException {
 
        CrunchifyInMemoryCacheTest cacheObj = new CrunchifyInMemoryCacheTest();
 
        System.out.println("\n\n==========AddRemoveObjects ==========");
        cacheObj.addRemoveObjects();
        System.out.println("\n\n==========ExpiredCacheObjects ==========");
        cacheObj.expiredCacheObjects();
        System.out.println("\n\n==========TestObjectsCleanupTime ==========");
        cacheObj.objectsCleanupTime();
    }
 
    private void addRemoveObjects() {
 
    	MemoryCache<String, String> cache = new MemoryCache<String, String>(300, 600, 5);
 
        cache.put("Shopee", "Shopee");
        cache.put("Lazada", "Lazada");
        cache.put("EAMart", "EAMart");
        cache.put("RedMart", "RedMart");
        cache.put("DBS", "DBS");
 
        System.out.println("5 Cache Object Added  cache.size(): " + cache.size());
        cache.remove("Lazada");
        System.out.println("One object removed.. cache.size(): " + cache.size());
 
        cache.put("Infosys", "Infosys");
        cache.put("UOB", "UOB");
        System.out.println("Two objects Added but reached maxItems.. cache.size(): " + cache.size());
 
    }
 
    private void expiredCacheObjects() throws InterruptedException {
 
        // Test with TimeToLive = 1 second
        // TimerInterval = 1 second
        // maxItems = 10
    	MemoryCache<String, String> cache = new MemoryCache<String, String>(1, 1, 10);
 
        cache.put("Lazada", "Lazada");
        cache.put("RedMart", "RedMart");
        // Adding 3 seconds sleep.. Both above objects will be removed from
        // Cache because of timeToLiveInSeconds value
        Thread.sleep(3000);
 
        System.out.println("Two objects are added but reached timeToLive. cache.size(): " + cache.size());
 
    }
 
    private void objectsCleanupTime() throws InterruptedException {
        int size = 500000;
 
        // timeToLiveInSeconds = 100 seconds
        // timerIntervalInSeconds = 100 seconds
        // maxItems = 500000
 
        MemoryCache<String, String> cache = new MemoryCache<String, String>(100, 100, 500000);
 
        for (int i = 0; i < size; i++) {
            String value = Integer.toString(i);
            cache.put(value, value);
        }
 
        Thread.sleep(200);
 
        long start = System.currentTimeMillis();
        cache.cleanup();
        double finish = (double) (System.currentTimeMillis() - start) / 1000.0;
 
        System.out.println("Cleanup times for " + size + " objects are " + finish + " s");
 
    }
}